// SalariedEmployee.cs
//
// Huimin Zhao
// 
// SalariedEmployee class that extends Employee.
using System;

[Serializable]
public class SalariedEmployee : Employee
{
    // private instance variable for storing weekly salary
    private decimal weeklySalaryValue;

    // parameter-less constructor
    public SalariedEmployee(): base()
    {
    }

   // constructor
    public SalariedEmployee(string first, string last, bool married, string gender, DateTime birthDate, Address homeAddress, PhoneNumber homePhone, PhoneNumber cellPhone, decimal weeklySalary)
        : base(first, last, married, gender, birthDate, homeAddress, homePhone, cellPhone)
   {
       this.WeeklySalary = weeklySalary; 
   } // end SalariedEmployee constructor

   // property that gets and sets salaried employee's salary
   public decimal WeeklySalary
   {
      get
      {
          return weeklySalaryValue;
      } // end get
      set
      {
          if (value < 0)
              throw new ApplicationException("Salary must not be negative!");
          weeklySalaryValue = value; 
      } // end set
   } // end property WeeklySalary

   // return string representation of SalariedEmployee object
   // calculate earnings; override Employee's abstract property Earnings 
   public override decimal Earnings
   {
       get
       {
           return WeeklySalary;
       }
   } // end property Earnings

   // override Employee's abstract property Category 
   public override string Category
   {
       get
       {
           return "Salaried";
       }
   } // end property Category

   // override Employee's abstract property TaxWithholdingPercentage 
   public override double TaxWithholdingPercentage
   {
       get
       {
           return 15;
       }
   } // end property TaxWithholdingPercentage

} // end class SalariedEmployee
