// Employee.cs
//
// Huimin Zhao
// 
// Employee abstract base class.

using System;

[Serializable]
public abstract class Employee
{
    // private instance variable for storing first name
    private string firstNameValue;

    // private instance variable for storing last name
    private string lastNameValue;

    // private instance variable for storing birth date
    private DateTime birthDateValue;

    // parameter-less constructor
    public Employee()
    {
    }

   // constructor
   public Employee( string first, string last, bool married, string gender, DateTime birthDate, Address homeAddress, PhoneNumber homePhone, PhoneNumber cellPhone)
   {
      this.FirstName = first;
      this.LastName = last;
      this.Married = married;
      this.Gender = gender;
      this.BirthDate = birthDate;
      this.HomeAddress = homeAddress;
      this.HomePhone = homePhone;
      this.CellPhone = cellPhone;
   } // end Employee constructor

   // property to get and set employee's first name
   public string FirstName
   {
      get
      {
          return Util.Capitalize(firstNameValue);
      } // end get
      set
      {
          value = value.Trim().ToUpper();
          if (value.Length < 1)
              throw new ApplicationException("First name is empty!");
          // check for letters
          foreach(char c in value)
              if(c<'A' || c>'Z')
                  throw new ApplicationException("First name must consist of letters only!");
          firstNameValue = value;
      } // end set
   } // end property FirstName

   // property to get and set employee's last name
   public string LastName
   {
      get
      {
          return Util.Capitalize(lastNameValue);
      } // end get
      set
      {
          value = value.Trim().ToUpper();
          if (value.Length < 1)
              throw new ApplicationException("Last name is empty!");
          // check for letters
          foreach (char c in value)
              if (c < 'A' || c > 'Z')
                  throw new ApplicationException("Last name must consist of letters only!");
          lastNameValue = value;
      } // end set
   } // end property LastName

   // read-only property to get employee's name
   public string Name
   {
       get
       {
           return LastName + ", " + FirstName;
       } // end get
   } // end property Name

   // property to get and set whether employee is married
   public bool Married {get; set;}

   // read-only property to get employee's marital status
   public string MaritalStatus
   {
       get
       {
           if (Married)
               return "married";
           else
               return "single";
       } // end get
   } // end property Name

   // property to get and set whether employee is male
   public bool IsMale {get; set;}

   // property to get and set whether employee is female
   public bool IsFemale
   {
      get
      {
         return !IsMale;
      } // end get
      set
      {
          IsMale = !value;
      } // end set
   } // end property IsFemale

   // property to get and set employee's gender
   public string Gender
   {
      get
      {
          if(IsMale)
              return "Male";
          else
              return "Female";
      } // end get
      set
      {
          value = value.ToUpper();
          if (value == "MALE" || value == "M")
              IsMale = true;
          else if (value == "FEMALE" || value == "F")
              IsMale = false;
          else
              throw new ApplicationException("Gender should be Male or Female!");
      } // end set
   } // end property Gender

   // read-only property to get employee's title
   public string Title
   {
       get
       {
           if (IsMale)
               return "Mr.";
           else
               return "Ms.";
       } // end get
   } // end property Title

   // read-only property to get employee's title and name
   public string TitleName
   {
       get
       {
           return Title + " " + Name;
       } // end get
   } // end property TitleName

    // property to get and set employee's birth date
   public DateTime BirthDate
   {
      get
      {
          return birthDateValue;
      } // end get
      set
      {
          if(value > DateTime.Now)
          {
              throw new ApplicationException("Employee birth date must be prior to today!");
          }
          birthDateValue = value;
      } // end set
  } // end property BirthDate

  // read-only property to get employee's age
  public byte Age
  {
      get
      {
          // Get the birth date value for the current year.

          DateTime thisYearBirthDate = new DateTime(DateTime.Now.Year, BirthDate.Month, BirthDate.Day);

          // Calculate and return the age based on if the birth date has occurred this year or not.

          if (thisYearBirthDate <= DateTime.Now)
          {
              return (byte)(DateTime.Now.Year - BirthDate.Year);
          }
          else
          {
              return (byte)(DateTime.Now.Year - BirthDate.Year - 1);
          }
      }
  }

  // property to get and set employee's home address
  public Address HomeAddress { get; set; }

  // property to get and set employee's home phone
  public PhoneNumber HomePhone { get; set; }

  // property to get and set employee's cell phone
  public PhoneNumber CellPhone { get; set; }

   // returns string representation of Employee object
   public override string ToString()
   {
       return TitleName + "\t" 
       + MaritalStatus + "\t" 
       + Category + "\t" 
       + HomeAddress;
   } // end method ToString

   // virtual readonly property for Category, will be overridden by derived classes
   public virtual string Category
   {
       get
       {
           return "Employee";
       }
   } // no implementation here

   // abstract readonly property for earnings, will be overridden by derived classes
   public abstract decimal Earnings
   {
       get;
   } // no implementation here

   // abstract readonly property for TaxWithholdingPercentage, will be overridden by derived classes
   public abstract double TaxWithholdingPercentage
   {
       get;
   } // no implementation here

   // read-only property to get employee's TaxWithheld
   public decimal TaxWithheld
   {
       get
       {
           return Earnings * (decimal)TaxWithholdingPercentage / 100;
       }
   }

} // end abstract class Employee
